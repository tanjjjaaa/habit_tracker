// Объект для постоянного хранения типов растений (чтобы одно растение не меняло вид при перезагрузке)
if (!window.plantTypesMap) {
    window.plantTypesMap = {};
}

function getPlantStage(percent) {
    if (percent <= 10) return 1;  // Этап 0-10%
    if (percent <= 30) return 2;  // Этап 10-30%
    if (percent <= 50) return 3;  // Этап 30-50%
    if (percent <= 75) return 4;  // Этап 50-75%
    if (percent <= 99) return 5;  // Этап 75-99%
    return 6;                     // Этап 100%
}

function renderGardenPage() {
    const row1 = document.getElementById('gardenRow1');
    const row2 = document.getElementById('gardenRow2');
    if (!row1 || !row2) return;

    // Очищаем старые полки перед рендером
    row1.innerHTML = '';
    row2.innerHTML = '';

    const currentHabits = window.habits || [];

    currentHabits.forEach((habit, index) => {
        // 1. Вычисляем процент как в кружке подробного прогресса
        const streakDays = habit.streak || 0;
        const circlePercent = Math.min(100, Math.round((streakDays / 66) * 100)) || 0;

        // 2. Получаем этап роста (1-6)
        const stage = getPlantStage(circlePercent);

        // 3. Закрепляем за привычкой случайный вид растения (1, 2 или 3), если его еще нет
        if (!window.plantTypesMap[habit.id || habit.name]) {
            window.plantTypesMap[habit.id || habit.name] = Math.floor(Math.random() * 3) + 1;
        }
        const plantType = window.plantTypesMap[habit.id || habit.name];

        // 4. Собираем имя файла картинки (например: plant_1_3.png)
        const imgSrc = `plant_${plantType}_${stage}.png`;

        // 5. Создаем DOM-элемент цветка в горшке
        const plantHtml = document.createElement('div');
        plantHtml.className = 'plant-item';
        plantHtml.innerHTML = `
            <img src="${imgSrc}" onerror="this.src='мем кот.png'; this.style.opacity='0.3';" alt="plant" class="plant-img">
            <div class="plant-label">${habit.name}</div>
        `;

        // Распределяем по полкам напрямую в блоки gardenRow1 и gardenRow2
        if (index < 3) {
            row1.appendChild(plantHtml);
        } else if (index < 6) {
                row2.appendChild(plantHtml);
        }
    });
}