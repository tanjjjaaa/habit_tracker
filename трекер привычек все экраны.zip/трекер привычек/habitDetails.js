function renderDetailedProgressPage() {
    const container = document.getElementById('detailedHabitsList');
    if (!container) return;

    container.innerHTML = '';

    // Берем привычки (из глобальной переменной habits, которая у вас в main.js)
    const currentHabits = window.habits || [];

    if (currentHabits.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding: 20px; color: #a0a0a0; font-size: 13px;">У вас пока нет добавленных привычек</div>';
        return;
    }

    currentHabits.forEach(habit => {
        // Вычисления на основе данных (если бэк их еще не считает, ставим безопасные нули или базовый расчет)
        const streakDays = habit.streak || 0; 
        const totalExecutions = habit.completedDates ? habit.completedDates.length : 0; 
        const totalPercent = habit.totalPercent || 0; 

        // Вычисление круга формирования (серия без пропусков / 66 дней)
        const circlePercent = Math.min(100, Math.round((streakDays / 66) * 100)) || 0;

        let freqText = 'ежедневно';
        if (habit.frequency === 'specific' && habit.days) {
            freqText = `${habit.days.length} раз(а) в неделю`;
        }

        const row = document.createElement('div');
        row.className = 'detailed-habit-row';
        row.innerHTML = `
            <div class="detailed-row-name">${habit.name}</div>
            <div class="detailed-row-freq">${freqText}</div>
            <div class="detailed-row-analysis">
                <div>${streakDays} дн. подр.</div>
                <div>${totalExecutions} вып.</div>
                <div>${totalPercent}% всего</div>
            </div>
            <div class="detailed-row-forming">
                <div class="compact-progress-circle" style="background: conic-gradient(#4be0cf ${circlePercent}%, #e0f2f1 ${circlePercent}%)">
                    <div class="compact-circle-inner">
                        <span class="compact-circle-percent">${circlePercent}%</span>
                    </div>
                </div>
            </div>
        `;

        container.appendChild(row);
    });
}