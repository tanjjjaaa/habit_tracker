let currentScreenIndex = 0;
const totalScreens = 6; // Теперь у нас ровно 5 экранов (0, 1, 2, 3, 4)
let isTransitioning = false; 

document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('appSlider');
    if (!slider) return;

    // Стартуем с 0 экрана
    switchScreen(0);

    // Кликабельность кружочков в шапке
    const dots = document.querySelectorAll('.header-circles .circle-dot');
    dots.forEach((dot, idx) => {
        dot.style.cursor = 'pointer';
        dot.addEventListener('click', () => switchScreen(idx));
    });

    let touchStartX = 0;
    let touchEndX = 0;

    // Свайпы для мобильных устройств
    slider.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].clientX;
    }, {passive: true});

    slider.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].clientX;
        handleSwipe(touchStartX - touchEndX);
    }, {passive: true});

    // Перетаскивание мышкой в браузере
    slider.addEventListener('mousedown', e => {
        touchStartX = e.clientX;
        document.addEventListener('mouseup', onMouseUp);
    });

    function onMouseUp(e) {
        touchEndX = e.clientX;
        handleSwipe(touchStartX - touchEndX);
        document.removeEventListener('mouseup', onMouseUp);
    }

    function handleSwipe(diff) {
        const swipeThreshold = 30;
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0 && currentScreenIndex < totalScreens - 1) {
                switchScreen(currentScreenIndex + 1);
            } else if (diff < 0 && currentScreenIndex > 0) {
                switchScreen(currentScreenIndex - 1);
            }
        }
    }
});

function switchScreen(index) {
    currentScreenIndex = index;
    const slider = document.getElementById('appSlider');
    if (!slider) return;

    isTransitioning = true;
    
    
    slider.style.transform = `translateX(-${index * (100 / 6)}%)`;
    
    setTimeout(() => {
        isTransitioning = false;
    }, 400);

    // Подсветка активного кружочка
    const dots = document.querySelectorAll('.header-circles .circle-dot');
    dots.forEach((dot, idx) => {
        if (idx === index) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });

    // Автоматический вызов рендера при переключении на экраны
    if (index === 2 && typeof initCalendar === 'function') {
        initCalendar();
        if (typeof renderHabits === 'function') renderHabits();
    }
    if (index === 3 && typeof renderProgressPage === 'function') {
        renderProgressPage();
    }
    
    // Если перешли на 5-й экран (индекс 4), вызываем функцию отрисовки сводной таблицы
    if (index === 4 && typeof renderDetailedProgressPage === 'function') {
        renderDetailedProgressPage();
    }
    if (index === 5 && typeof renderGardenPage === 'function') {
    renderGardenPage();
    }

    // Плюсик модалки виден только на экране Календаря (индекс 2)
    const plusBtn = document.getElementById('openModalBtn');
    if (plusBtn) {
        plusBtn.style.display = (index === 2) ? 'flex' : 'none';
    }
}