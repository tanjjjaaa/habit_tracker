// Адрес живого сервера твоей одногруппницы, который ты нашла (ЗАКОММЕНТИРОВАН НА ВРЕМЯ ТЕСТОВ)
// const API_URL = 'https://63e5ebe1-0ee9-4762-a0cb-9cb2fa454c06.tunnel4.com/api';

// 1. Функция переключения вкладок (Вход / Регистрация)
function switchMode(mode) {
    const container = document.getElementById('authContainer');
    const tabLogin = document.getElementById('tabLogin');
    const tabRegister = document.getElementById('tabRegister');
    const submitBtn = document.getElementById('submitBtn');

    if (!container || !tabLogin || !tabRegister || !submitBtn) return;

    if (mode === 'register') {
        container.classList.add('register-mode');
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        submitBtn.innerHTML = 'регистрация &rarr;'; 
    } else {
        container.classList.remove('register-mode');
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        submitBtn.innerHTML = 'войти &rarr;';
    }
}

// 2. Логика обработки отправки формы авторизации
document.addEventListener('DOMContentLoaded', () => {
    const authForm = document.getElementById('authForm');
    if (!authForm) return;

    authForm.addEventListener('submit', async function(event) {
        event.preventDefault(); // Предотвращаем перезагрузку страницы

        const loginValue = document.getElementById('login').value.trim();
        const passwordValue = document.getElementById('password').value;
        const confirmPasswordValue = document.getElementById('confirmPassword').value;
        const container = document.getElementById('authContainer');
        
        if (!container) return;
        const isRegisterMode = container.classList.contains('register-mode');

        if (!loginValue || !passwordValue) {
            alert('Пожалуйста, заполните все обязательные поля!');
            return;
        }

        if (isRegisterMode) {
            // --- РЕЖИМ РЕГИСТРАЦИИ (ВРЕМЕННАЯ ЗАГЛУШКА) ---
            alert('Тестовый режим: Регистрация успешна! Переключаем на вход.');
            switchMode('login');

            /* --- Реальный код регистрации (закомментирован) ---
            const nameValue = document.getElementById('name').value.trim();
            if (!nameValue) {
                alert('Пожалуйста, введите ваше имя!');
                return;
            }
            if (passwordValue !== confirmPasswordValue) {
                alert('Пароли не совпадают!');
                return;
            }

            try {
                const response = await fetch(`${API_URL}/auth/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: nameValue,
                        login: loginValue,
                        password: passwordValue
                    })
                });
                const data = await response.json();
                if (response.ok) {
                    alert('Регистрация успешна! Теперь вы можете войти.');
                    switchMode('login');
                } else {
                    alert(data.message || 'Ошибка при регистрации');
                }
            } catch (error) {
                console.error('Ошибка сети:', error);
                alert('Не удалось связаться с сервером бэкенда.');
            }
            -------------------------------------------------- */

        } else {
            // --- ТЕСТОВЫЙ РЕЖИМ ВХОДА БЕЗ БЭКЕНДА (ЗАГЛУШКА) ---
            console.log('Вход в тестовом режиме bypass сервера');
            
            // Искусственно создаем массив привычек в памяти, чтобы Сад и Таблица не были пустыми.
            // У них разные streak (серии дней), чтобы проверить все 6 этапов роста растений:
            window.habits = [
                { id: 1, name: "Пить воду", streak: 66, frequency: "everyday", completedDates: [1,2,3], totalPercent: 100 }, // 100% (6 этап роста)
                { id: 2, name: "Зарядка", streak: 25, frequency: "everyday", completedDates: [1,2], totalPercent: 38 },     // ~38% (3 этап роста)
                { id: 3, name: "Чтение книг", streak: 5, frequency: "specific", days: [1,3,5], completedDates: [1], totalPercent: 8 }, // ~7% (1 этап роста)
                { id: 4, name: "Медитация", streak: 45, frequency: "everyday", completedDates: [1,2,3,4], totalPercent: 68 }, // ~68% (4 этап роста)
                { id: 5, name: "Английский", streak: 58, frequency: "everyday", completedDates: [1,2,5], totalPercent: 87 }   // ~87% (5 этап роста)
            ];

            // Сразу пускаем на экран Кота-Босса
            if (typeof switchScreen === 'function') {
                switchScreen(1);
            } else {
                const bossPage = document.getElementById('bossPage');
                if (container) container.style.display = 'none';
                if (bossPage) bossPage.style.display = 'flex';
            }
            return; // Прерываем выполнение, чтобы реальный fetch ниже не вызывался

            /* --- Реальный код входа (закомментирован) ---
            try {
                const response = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        login: loginValue,
                        password: passwordValue
                    })
                });
                const data = await response.json();

                if (response.ok) {
                    if (data.token) localStorage.setItem('token', data.token);
                    if (data.user && data.user.id) localStorage.setItem('userId', data.user.id);
                    
                    if (typeof switchScreen === 'function') {
                        switchScreen(1);
                    } else {
                        const bossPage = document.getElementById('bossPage');
                        if (container) container.style.display = 'none';
                        if (bossPage) bossPage.style.display = 'flex';
                    }
                } else {
                    alert(data.message || 'Неверный логин или пароль!');
                }
            } catch (error) {
                console.error('Ошибка сети:', error);
                alert('Не удалось связаться с сервером бэкенда.');
            }
            ------------------------------------------------ */
        }
    });

    // Нажатие на кнопку "дальше" на экране Босса
    const goToMainBtn = document.getElementById('goToMainBtn');
    if (goToMainBtn) {
        goToMainBtn.addEventListener('click', () => {
            if (typeof switchScreen === 'function') {
                switchScreen(2); // Листаем на экран 2 (Календарь)
            } else {
                const bossPage = document.getElementById('bossPage');
                const mainCont = document.querySelector('.main-container');
                if (bossPage) bossPage.style.display = 'none';
                if (mainCont) mainCont.style.display = 'flex';
            }
        });
    }
});