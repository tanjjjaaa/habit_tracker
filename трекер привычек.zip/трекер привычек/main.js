// Константы месяцев на русском
const MONTHS_RU = ["ЯНВАРЬ", "ФЕВРАЛЬ", "МАРТ", "АПРЕЛЬ", "МАЙ", "ИЮНЬ", "ИЮЛЬ", "АВГУСТ", "СЕНТЯБРЬ", "ОКТЯБРЬ", "НОЯБРЬ", "ДЕКАБРЬ"];

// Состояние приложения
let currentDate = new Date(); // Хранит текущий месяц для календаря
let selectedDate = new Date(); // <--- НОВАЯ: Хранит дату, которую пользователь выбрал кликом
let habits = JSON.parse(localStorage.getItem('user_habits')) || [];

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    initCalendar();
    renderHabits();
    setupModalEvents();

    document.getElementById('prevMonthBtn').addEventListener('click', () => changeMonth(-1));
    document.getElementById('nextMonthBtn').addEventListener('click', () => changeMonth(1));
});

// 1. РАБОТА С КАЛЕНДАРЕМ
function initCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    // Ставим название месяца в шапку
    document.getElementById('monthTitle').innerText = MONTHS_RU[month];

    const container = document.getElementById('calendarDays');
    container.innerHTML = ''; // Очищаем сетку

    // Получаем данные для текущего месяца
    const firstDayIndex = new Date(year, month, 1).getDay(); 
    const startOffset = firstDayIndex === 0 ? 6 : firstDayIndex - 1; // Сколько дней до Пн
    const totalDays = new Date(year, month + 1, 0).getDate();

    // Создаем объект реального сегодняшнего дня (для сравнения)
    const realToday = new Date();

    // 1. ДНИ ПРЕДЫДУЩЕГО МЕСЯЦА
    const prevMonthTotalDays = new Date(year, month, 0).getDate();
    for (let i = startOffset - 1; i >= 0; i--) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day-cell neighbor-month-day';
        const dayNum = prevMonthTotalDays - i;
        dayCell.innerText = dayNum;

        const cellDate = new Date(year, month - 1, dayNum);
        setupDayClick(dayCell, cellDate, realToday);

        container.appendChild(dayCell);
    }

    // 2. ДНИ ТЕКУЩЕГО МЕСЯЦА
    for (let day = 1; day <= totalDays; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day-cell';
        dayCell.innerText = day;

        const cellDate = new Date(year, month, day);
        setupDayClick(dayCell, cellDate, realToday);

        container.appendChild(dayCell);
    }

    // 3. ДНИ СЛЕДУЮЩЕГО МЕСЯЦА
    const totalCellsRendered = startOffset + totalDays;
    const remainingCells = 42 - totalCellsRendered;
    for (let day = 1; day <= remainingCells; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day-cell neighbor-month-day';
        dayCell.innerText = day;

        const cellDate = new Date(year, month + 1, day);
        setupDayClick(dayCell, cellDate, realToday);

        container.appendChild(dayCell);
    }
}

// Функция переключения месяцев
function changeMonth(direction) {
    // direction может быть -1 (предыдущий месяц) или 1 (следующий)
    const currentMonth = currentDate.getMonth();
    currentDate.setMonth(currentMonth + direction);
    
    initCalendar(); // Перерисовываем календарь с новым месяцем!
}

// Исправленная функция обработки кликов и мгновенной подсветки
function setupDayClick(element, cellDate, realToday) {
    // Проверяем, совпадает ли ячейка с реальным СЕГОДНЯШНИМ днем
    const isToday = cellDate.getDate() === realToday.getDate() &&
                    cellDate.getMonth() === realToday.getMonth() &&
                    cellDate.getFullYear() === realToday.getFullYear();

    // Проверяем, совпадает ли ячейка с ВЫБРАННЫМ днем
    const isSelected = cellDate.getDate() === selectedDate.getDate() &&
                       cellDate.getMonth() === selectedDate.getMonth() &&
                       cellDate.getFullYear() === selectedDate.getFullYear();

    // Всегда красим реальный сегодняшний день в зеленый цвет текста
    if (isToday) {
        element.classList.add('current-day');
    }

    // Если этот день выбран, сразу вешаем класс выделения кружком
    if (isSelected) {
        element.classList.add('selected-day');
    }

    // Клик срабатывает моментально и сразу обновляет интерфейс
    element.onclick = function() {
        selectedDate = cellDate; // Обновляем выбранную дату
        initCalendar();          // Сразу же перерисовываем календарь, обводка появится мгновенно!
        renderHabits();          // Обновляем список задач
    };
}

function toggleDaysSelection() {
    const frequency = document.getElementById('habitFrequency').value;
    // ИСПРАВЛЕНО: заменен ID на daysCheckboxesGroup из HTML
    const daysGroup = document.getElementById('daysCheckboxesGroup');
    
    if (!daysGroup) return;

    if (frequency === 'specific') {
        daysGroup.style.display = 'flex';
    } else {
        daysGroup.style.display = 'none';
    }
}

// Управление открытием/закрытием окна
function setupModalEvents() {
    // ИСПРАВЛЕНО: берем правильный ID модалки из нашего HTML ('habitModal')
    const overlay = document.getElementById('habitModal'); 
    if (!overlay) return; // Защита от ошибок, если элемент еще не создался
    
    document.getElementById('openModalBtn').addEventListener('click', () => {
        overlay.style.display = 'flex';
        overlay.classList.add('active'); // Добавляем класс, чтобы включить pointer-events в CSS
    });
    
    document.getElementById('closeModalBtn').addEventListener('click', () => {
        overlay.style.display = 'none';
        overlay.classList.remove('active'); // Убираем класс активности
        document.getElementById('habitForm').reset();
        if (typeof toggleDaysSelection === 'function') toggleDaysSelection();
    });

    // Сохранение новой привычки
    document.getElementById('habitForm').addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('habitName').value.trim();
        const frequency = document.getElementById('habitFrequency').value;
        const color = document.querySelector('input[name="habitColor"]:checked').value;
        
        let selectedDays = [];
        if (frequency === 'specific') {
            // ИСПРАВЛЕНО: ищем чекбоксы внутри правильного контейнера '#daysCheckboxesGroup'
            const checkedBoxes = document.querySelectorAll('#daysCheckboxesGroup input[type="checkbox"]:checked');
            checkedBoxes.forEach(box => selectedDays.push(parseInt(box.value)));
        }

        const newHabit = {
            id: Date.now().toString(),
            name: name,
            frequency: frequency, // 'everyday' или 'specific'
            days: selectedDays,    // Массив индексов дней [1, 3, 5]
            color: color,
            completedDates: []     // Будем хранить даты "YYYY-MM-DD", когда привычка была выполнена
        };

        habits.push(newHabit);
        
        // Сохраняем и обновляем интерфейс
        if (typeof saveToDB === 'function') saveToDB();
        if (typeof renderHabits === 'function') renderHabits();
        
        // Закрываем модалку и сбрасываем форму
        overlay.style.display = 'none';
        overlay.classList.remove('active'); // Убираем класс активности
        document.getElementById('habitForm').reset();
        if (typeof toggleDaysSelection === 'function') toggleDaysSelection();
    });
}

// 3. СВЯЗЬ С ИМИТАЦИЕЙ БАЗЫ ДАННЫХ И ОТРИСОВКА НА СТРАНИЦЕ
function saveToDB() {
    localStorage.setItem('user_habits', JSON.stringify(habits));
}

function renderHabits() {
    const uncompletedContainer = document.getElementById('uncompletedHabitsList');
    const completedContainer = document.getElementById('completedHabitsList');
    const divider = document.getElementById('habitsDivider');

    uncompletedContainer.innerHTML = '';
    completedContainer.innerHTML = '';

    // ТЕПЕРЬ СМОТРИМ НА ВЫБРАННУЮ ПОЛЬЗОВАТЕЛЕМ ДАТУ:
    const offset = selectedDate.getTimezoneOffset();
    const localSelected = new Date(selectedDate.getTime() - (offset * 60 * 1000));
    const todayStr = localSelected.toISOString().split('T')[0]; 
    const currentDayOfWeek = selectedDate.getDay(); // 0 (Вс) - 6 (Сб)

    // Фильтруем привычки, которые актуальны именно на сегодняшний день недели
    const todaysHabits = habits.filter(habit => {
        if (habit.frequency === 'everyday') return true;
        if (habit.frequency === 'specific') {
            return habit.days.includes(currentDayOfWeek);
        }
        return false;
    });

    let hasCompleted = false;

    todaysHabits.forEach(habit => {
        const isDoneToday = habit.completedDates.includes(todayStr);

        const habitHtml = document.createElement('div');
        habitHtml.className = `habit-item ${isDoneToday ? 'completed' : ''}`;
        habitHtml.innerHTML = `
            <div class="habit-left">
                <div class="habit-checkbox ${isDoneToday ? 'checked' : ''}" 
                     style="border-color: ${habit.color}; ${isDoneToday ? `background-color: ${habit.color}` : ''}"
                     onclick="toggleHabitStatus('${habit.id}', '${todayStr}')">
                </div>
                <span class="habit-text">${habit.name}</span>
            </div>
            <a class="reminder-link">Добавить напоминание</a>
        `;

        if (isDoneToday) {
            completedContainer.appendChild(habitHtml);
            hasCompleted = true;
        } else {
            uncompletedContainer.appendChild(habitHtml);
        }
    });

    // Показываем пунктирный разделитель, только если есть хотя бы одна выполненная задача
    divider.style.display = hasCompleted ? 'block' : 'none';
}

// Переключение галочки выполнения привычки
function toggleHabitStatus(habitId, dateStr) {
    const habit = habits.find(h => h.id === habitId);
    if (!habit) return;

    const index = habit.completedDates.indexOf(dateStr);
    if (index > -1) {
        // Если уже была выполнена сегодня — отменяем выполнение
        habit.completedDates.splice(index, 1);
    } else {
        // Если не была выполнена — добавляем текущую дату выполнения
        habit.completedDates.push(dateStr);
    }

    saveToDB();
    renderHabits();
}